﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Calculator
/// </summary>
public class Calculator
{
    public Calculator()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public double Add(double a, double b)
    {
        return (a + b);
    }

    public object add(double a, double b)
    {
        throw new NotImplementedException();
    }

    public double Minus(double a, double b)
    {
        return (a - b);
    }
    public object minus(double a, double b)
    {
        throw new NotImplementedException();
    }

    public double Times(double a, double b)
    {
        return (a * b);
    }
    public object times(double a, double b)
    {
        throw new NotImplementedException();
    }

    public double Divide(double a, double b)
    {
        return (a / b);
    }
    public object divide(double a, double b)
    {
        throw new NotImplementedException();
    }
}