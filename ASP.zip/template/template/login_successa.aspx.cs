﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class template_login_success : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String theUserName = (String)(Session["sahid"]); //added
        lbl_welcome.Text = "Welcome " + theUserName  ; //added

    }

    protected void btn_logout_Click(object sender, EventArgs e)
    {
        Response.Redirect("login_forma.aspx");
    }
}