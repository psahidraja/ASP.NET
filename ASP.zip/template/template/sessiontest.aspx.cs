﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class template_sessiontest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String theUserName = (String)(Session["UserName"]);
        String theUserName1 = Request.Cookies["UserName"]["UserName"];
        String theTime = Request.Cookies["UserName"]["LastVisit"];

        Label2.Text = "Hello " + theUserName + " You have passed this information a session variable";
        Label3.Text = "Hello " + theUserName1 + " You have passed this information in a cookie at " + theTime;

    }
}