﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class template_exercise10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        numbersTableAdapters.numbersTableAdapter num = new numbersTableAdapters.numbersTableAdapter();
        numbers.numbersDataTable numtable = num.GetData();
        lbl_result.Text = "";
        foreach (DataRow row in numtable.Rows)
            if (txt_search.Text == System.Convert.ToString(row["number1"]))
            {
                lbl_result.Text = lbl_result.Text + "</br>" + "Mr " + System.Convert.ToString(row["lastName"]) + ", your number matches";
            }
    }

    protected void ObjectDataSource1_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
    {
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}