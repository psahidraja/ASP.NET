﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Web.UI.ScriptManager;
//using System.Object;
//using System.Web.UI.Control;

public partial class template_exercise2 : System.Web.UI.Page
{
   int[] numbers;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ViewState["mynumbers"] != null)
        {
            numbers = (int[])ViewState["mynumbers"];
        }
    }



    protected void generate_Click(object sender, EventArgs e)
    {
        Random RandomClass = new Random();
        numbers = new int[6];
        for(int i = 0; i < 6; i++)
        {
           numbers[i] = RandomClass.Next(1, 50);
        }

        ViewState["mynumbers"] = numbers;

        TextBox1.Text = Convert.ToString(numbers[0]);
        TextBox2.Text = Convert.ToString(numbers[1]);
        TextBox3.Text = Convert.ToString(numbers[2]);
        TextBox4.Text = Convert.ToString(numbers[3]);
        TextBox5.Text = Convert.ToString(numbers[4]);
        TextBox6.Text = Convert.ToString(numbers[5]);
        setColor();
    }

    private void setColor()
    {
        List<TextBox> myTextBoxList = new List<TextBox>();
        myTextBoxList.Add(TextBox1);
        myTextBoxList.Add(TextBox2);
        myTextBoxList.Add(TextBox3);
        myTextBoxList.Add(TextBox4);
        myTextBoxList.Add(TextBox5);
        myTextBoxList.Add(TextBox6);
////////////////////////////////////////////////
        for (int i = 0; i < 6; i++)
        {
            if (numbers[i] < 10)
            {
                myTextBoxList[i].BackColor = System.Drawing.Color.White;
            }
            else if (numbers[i] < 20)
            {
                myTextBoxList[i].BackColor = System.Drawing.Color.Blue;
            }
            else if(numbers[i] < 30)
            {
                myTextBoxList[i].BackColor = System.Drawing.Color.Pink;
            }
            else if(numbers[i] < 40)
            {
                myTextBoxList[i].BackColor = System.Drawing.Color.Green;
            }
            else if (numbers[i] < 50)
            {
                myTextBoxList[i].BackColor = System.Drawing.Color.Yellow;
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
     //   numbers[0] = System.Convert.ToInt32(TextBox1.Text);



        Array.Sort(numbers);
        TextBox1.Text = Convert.ToString(numbers[0]);
        TextBox2.Text = Convert.ToString(numbers[1]);
        TextBox3.Text = Convert.ToString(numbers[2]);
        TextBox4.Text = Convert.ToString(numbers[3]);
        TextBox5.Text = Convert.ToString(numbers[4]);
        TextBox6.Text = Convert.ToString(numbers[5]);
    }
}