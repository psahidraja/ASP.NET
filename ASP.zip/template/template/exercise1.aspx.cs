﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class template_exercise1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void btn_claclulate_Click(object sender, EventArgs e)
    {
        double a = 0, b = 0;
        Calculator myCalc = new Calculator(); //instantiating an object of a Calculator class
        //try code starts from here
        try
        {
            a = System.Convert.ToDouble(txt_num1.Text);
            b = System.Convert.ToDouble(txt_num2.Text);

            if (RadioButtonList1.SelectedItem.Value == "Add")
            {
                lbl_operand.Text = "+";//this is simply saying which operand the user have select from the RadioButtonList i.e +
                //lbl_result.Text = (a + b).ToString();
                lbl_result.Text = myCalc.Add(a, b).ToString();//converting objects in to a string 

            }
            if (RadioButtonList1.SelectedItem.Value == "Minus")
            {
                lbl_operand.Text = "-";//this is simply saying which operand the user have select from the RadioButtonList i.e -
                //lbl_result.Text = (a - b).ToString();
                lbl_result.Text = myCalc.Minus(a, b).ToString();//converting objects in to a string 

            }
            if (RadioButtonList1.SelectedItem.Value == "Times")
            {
                lbl_operand.Text = "*";//this is simply saying which operand the user have select from the RadioButtonList i.e *
                //lbl_result.Text = (a * b).ToString();
                lbl_result.Text = myCalc.Times(a, b).ToString();//converting objects in to a string 
            }
            if (RadioButtonList1.SelectedItem.Value == "Divide")
            {
                lbl_operand.Text = "/";//this is simply saying which operand the user have select from the RadioButtonList i.e /
                                       //lbl_result.Text = (a / b).ToString();
                lbl_result.Text = myCalc.Divide(a, b).ToString();//converting objects in to a string 
            }

        }
        //catch starts from here this will run after the try code
        catch
        {
            lbl_result.Text = "Not a number"; //this message appears if the user has typed letter or any other symbols than numbers
        }

    }//end of btn_claclulate_Click method here 
}//end of class template_exercise1