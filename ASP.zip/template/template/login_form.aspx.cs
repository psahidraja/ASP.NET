﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class template_login_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        Session["sahid"] = txt_username.Text;
        //Session["sahid"] = txt_password.Text;

        if (txt_username.Text == "sahid" && txt_password.Text == "sahid")
        {
            Response.Redirect("login_success.aspx?" + txt_username.Text);
        }
        else{
            lbl_error.Visible = true;
        }

        /*if (txt_username.Text == "sahid" && txt_password.Text == "sahid")//working one
        {
            Response.Redirect("login_success.aspx");
        }
        else{
            lbl_error.Visible = true;
        }*/
    }
}