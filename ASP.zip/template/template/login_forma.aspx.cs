﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class template_login_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            txt_generate.Text = genCap();
    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        Session["sahid"] = txt_username.Text;

        if (txt_username.Text == "sahid@gmail.com" && txt_password.Text == "sahid" && txt_check.Text == txt_generate.Text)
        {
            Response.Redirect("login_successa.aspx?" + txt_username.Text);
        }


        
    }

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        txt_generate.Text = genCap();
    }
    string genCap()
    {
        String captcha;

        var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var stringChars = new char[8];
        var random = new Random();

        for (int i = 0; i < stringChars.Length; i++)
        {
            stringChars[i] = chars[random.Next(chars.Length)];
        }

        var finalString = new String(stringChars);
        return finalString;
    }
}